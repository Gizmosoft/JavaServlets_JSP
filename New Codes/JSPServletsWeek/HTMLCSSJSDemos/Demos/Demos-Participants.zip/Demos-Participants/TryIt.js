function validateForm() {
	var eid = document.getElementById("eid").value;
	var ename = document.getElementById("ename").value;

	/* Topic : Javascript
	 * Instructions:
	 * 		Ensure that the employee id and name are not empty.
	 *
	 * Hint:
	 * Use the length property of the variable
	 *
	 */ 
	
}
