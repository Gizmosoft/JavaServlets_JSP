function addStudent(){
	alert("Registering "+document.getElementById("sname").value+" ...")
}
