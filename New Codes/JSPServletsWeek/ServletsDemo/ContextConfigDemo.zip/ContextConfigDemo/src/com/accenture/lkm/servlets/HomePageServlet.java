package com.accenture.lkm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HomePageServlet
 */
public class HomePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String color;
	private String title;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HomePageServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		color = config.getInitParameter("luckyColor");
		title = config.getServletContext().getInitParameter("caption");
		System.out.println(title);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		out.print("<html><head><title>Home page</title></head>");
		out.print("<body><h4> Unicorn Fibre net Services. Choose your area");
		out.print("<h3>Your lucky color is " + color);
		out.write(title + "</h3>");
		out.print("<select> <option> New Delhi</option> <option> Bengaluru</option>");
		out.print("<option> Hyderabad</option> <option> Chennai</option>");
		out.print("<option> Kolkatta</option></select></h4></body></html>");

	}

}
