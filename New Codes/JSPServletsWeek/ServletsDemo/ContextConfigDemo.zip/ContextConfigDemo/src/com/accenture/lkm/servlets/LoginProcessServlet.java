package com.accenture.lkm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginProcessServlet
 */
public class LoginProcessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String color;
	private String title;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginProcessServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		color = config.getInitParameter("luckyColor");
		title = config.getServletContext().getInitParameter("caption");
		System.out.println(title);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uName = request.getParameter("userName");
		String pass = request.getParameter("password");
		PrintWriter out = response.getWriter();
		if (!uName.isEmpty() && !pass.isEmpty()) {
			out.write("<html><head><title>Home page</title></head>");
			out.write("<body><h3>Login is successful!!! Welcome " + uName);
			out.write(title);
			out.print("Your lucky color is " + color + "</h3>");
			out.write("<h4> To view home page <a href='Home'> click here </a></h4>");
			out.write("</body></html>");

		} else {
			out.write("<html><head><title>Error page</title></head>");
			out.write("<body><h3>Login is unsuccessful!!! </h3>");
			out.write("<h4> To Login <a href='Login.html'> click here </a></h4>");
			out.write("</body></html>");
		}

	}

}
