package com.accenture.lkm.webapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uName = request.getParameter("userName");
		String pass = request.getParameter("password");
		PrintWriter out = response.getWriter();
		if (uName.equals("admin") && pass.equals("admin")) {
			out.write("<html><head><title>Home page</title></head>");
			out.write("<body><h4>Login successful!!!!. Welcome " + uName);
			out.write("</body></html>");
		} else {
			out.write("<html><head><title>Error page</title></head>");
			out.write("<body><h4>Login  unsuccessful!!!!.");
			out.write("</body></html>");
		}
	}

}
