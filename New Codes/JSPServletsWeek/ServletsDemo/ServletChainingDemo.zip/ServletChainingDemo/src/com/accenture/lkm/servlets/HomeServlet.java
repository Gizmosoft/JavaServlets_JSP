package com.accenture.lkm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HomeServlet
 */
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HomeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.write("<html><head><title>Home page </title></head><body>");
		RequestDispatcher dispatch = request.getRequestDispatcher("Header");
		dispatch.include(request, response);
		out.write("<h4>We offer a wide-range of apps to Indian citizens to avail central govt. services");
		out.write("<ol><li>ePathshala app</li><li>mParivahan app</li><li>DigiSevak app</li></ol>");
		out.write("</body></html>");
	}

}
